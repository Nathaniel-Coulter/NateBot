export const PRIMARY_BROWN = '#252422';
