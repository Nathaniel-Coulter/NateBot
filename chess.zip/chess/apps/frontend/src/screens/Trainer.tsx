// apps/frontend/src/screens/Trainer.tsx
import { useMemo, useState, useEffect } from "react";
import { Chess, Square } from "chess.js";
import { ChessBoard } from "../components/ChessBoard";
import { useRecoilValue, useSetRecoilState } from "recoil";
import {
  movesAtom,
  userSelectedMoveIndexAtom,
  isBoardFlippedAtom,
} from "@repo/store/chessBoard";
import {
  fetchOpeningStats,
  fetchEngineBestLines,
  type EngineLine,
} from "../lib/lambdaClient";

// Types matching the opening-stats API response
type OpeningMove = {
  uci: string;
  san: string;
  games: number;
  p_white: number;
  p_draw: number;
  p_black: number;
};

type OpeningStats = {
  total_games: number;
  moves: OpeningMove[];
};

function uciToSquares(
  uci: string | undefined | null
): { from: Square; to: Square } | null {
  if (!uci || uci.length < 4) return null;
  const from = uci.slice(0, 2) as Square;
  const to = uci.slice(2, 4) as Square;
  return { from, to };
}

export const Trainer = () => {
  const [chess] = useState(() => new Chess());
  const [board, setBoard] = useState(chess.board());

  const setMoves = useSetRecoilState(movesAtom);
  const setUserSelectedMoveIndex = useSetRecoilState(
    userSelectedMoveIndexAtom
  );
  const setIsBoardFlipped = useSetRecoilState(isBoardFlippedAtom);

  const moves = useRecoilValue(movesAtom);

  // Opening stats state
  const [openingStats, setOpeningStats] = useState<OpeningStats | null>(null);
  const [isComputingOpening, setIsComputingOpening] = useState(false);

  // Engine best lines
  const [engineLines, setEngineLines] = useState<EngineLine[]>([]);
  const [isComputingEngine, setIsComputingEngine] = useState(false);

  const sideToMove = chess.turn() === "w" ? "White" : "Black";

  const dummySocket = useMemo(
    () =>
      ({
        send: (_: any) => {
          /* no-op for trainer */
        },
      } as unknown as WebSocket),
    []
  );

  async function updateOpeningStatsForCurrentPosition() {
    const fen = chess.fen();
    try {
      setIsComputingOpening(true);
      const stats = await fetchOpeningStats(fen);
      setOpeningStats(stats);
    } catch (e) {
      console.error("opening stats error:", e);
      setOpeningStats(null);
    } finally {
      setIsComputingOpening(false);
    }
  }

  async function updateEngineForCurrentPosition() {
    const fen = chess.fen();
    try {
      setIsComputingEngine(true);
      const lines = await fetchEngineBestLines(fen);
      setEngineLines(lines);
    } catch (e) {
      console.error("engine error:", e);
      setEngineLines([]);
    } finally {
      setIsComputingEngine(false);
    }
  }

  // Initial stats
  useEffect(() => {
    updateOpeningStatsForCurrentPosition();
    updateEngineForCurrentPosition();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // On every move change, recompute stats & engine lines
  useEffect(() => {
    if (!moves) return;
    updateOpeningStatsForCurrentPosition();
    updateEngineForCurrentPosition();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moves]);

  const handleUndo = () => {
    const undone = chess.undo();
    if (!undone) return;

    setBoard(chess.board());
    setMoves((prev) => prev.slice(0, -1));
    setUserSelectedMoveIndex(null);

    updateOpeningStatsForCurrentPosition();
    updateEngineForCurrentPosition();
  };

  const handleFlip = () => {
    setIsBoardFlipped((prev) => !prev);
  };

  // 🔹 Top hint moves (converted from UCI to board squares)
  const topMostPlayedMove =
    openingStats && openingStats.moves.length > 0
      ? uciToSquares(openingStats.moves[0].uci)
      : null;

  const topEngineMove =
    engineLines && engineLines.length > 0
      ? uciToSquares(engineLines[0].move)
      : null;

  return (
    <div className="flex justify-center pt-8">
      <div className="flex flex-col items-center">
        <div className="flex gap-6 items-start">
          {/* Board */}
          <ChessBoard
            started={true}
            gameId="trainer"
            myColor={"w"}
            chess={chess}
            board={board}
            setBoard={setBoard}
            socket={dummySocket}
            mostPlayedMove={topMostPlayedMove}
            bestEngineMove={topEngineMove}
          />

          {/* Metrics panel to the right of the board */}
          <div className="text-white w-72 space-y-4">
            {isComputingOpening && (
              <div className="mb-2 bg-black/50 px-4 py-2 rounded-md text-sm animate-pulse">
                Fetching opening stats…
              </div>
            )}

            {openingStats && openingStats.moves.length > 0 && (
              <div className="bg-black/60 px-4 py-3 rounded-md text-sm">
                <div className="font-semibold mb-1">Most played moves</div>

                <div className="text-xs text-gray-300 mb-1">
                  Side to move:{" "}
                  <span className="font-semibold">{sideToMove}</span>
                </div>

                <div className="text-xs text-gray-300 mb-2">
                  Based on {openingStats.total_games} games
                </div>
                {openingStats.moves.slice(0, 3).map((m) => (
                  <div key={m.uci} className="flex justify-between mb-1">
                    <span>{m.san}</span>
                    <span className="text-xs text-gray-300">
                      {m.games} games • W {Math.round(m.p_white * 100)}% / D{" "}
                      {Math.round(m.p_draw * 100)}% / B{" "}
                      {Math.round(m.p_black * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Engine box */}
            <div className="bg-black/60 px-4 py-3 rounded-md text-sm">
              <div className="font-semibold mb-1">
                Engine Best Moves (Stockfish)
              </div>
              {isComputingEngine && (
                <div className="text-xs text-gray-300 mb-2 animate-pulse">
                  Evaluating position…
                </div>
              )}
              {engineLines.slice(0, 3).map((line, idx) => (
                <div key={line.move} className="flex justify-between mb-1">
                  <span>
                    {idx + 1}. {line.pretty || line.move}
                  </span>
                  <span className="text-xs text-gray-300">
                    Eval: {line.score.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-4 flex gap-4">
          <button
            onClick={handleUndo}
            className="bg-[#d355dd] hover:bg-[#5AA63F] text-white px-4 py-2 rounded-md text-sm"
          >
            ⏪ Undo move
          </button>
          <button
            onClick={handleFlip}
            className="bg-[#d355dd] hover:bg-[#5AA63F] text-white px-4 py-2 rounded-md text-sm"
          >
            🔁 Flip board
          </button>
        </div>
      </div>
    </div>
  );
};