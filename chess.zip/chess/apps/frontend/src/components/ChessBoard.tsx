// apps/frontend/src/components/ChessBoard.tsx
import { Chess, Color, Move, PieceSymbol, Square } from "chess.js";
import { MouseEvent, memo, useEffect, useState } from "react";
import { MOVE } from "../screens/Game";
import LetterNotation from "./chess-board/LetterNotation";
import LegalMoveIndicator from "./chess-board/LegalMoveIndicator";
import ChessSquare from "./chess-board/ChessSquare";
import NumberNotation from "./chess-board/NumberNotation";
import { drawArrow } from "../utils/canvas";
import Confetti from "react-confetti";
import moveSoundFile from "/move.wav";
import captureSoundFile from "/capture.wav";

import { useRecoilState } from "recoil";

import {
  isBoardFlippedAtom,
  movesAtom,
  userSelectedMoveIndexAtom,
} from "@repo/store/chessBoard";

import { fetchLambda } from "../lib/lambdaClient";

export function isPromoting(chess: Chess, from: Square, to: Square) {
  if (!from) return false;

  const piece = chess.get(from);
  if (piece?.type !== "p") return false;
  if (piece.color !== chess.turn()) return false;
  if (!["1", "8"].some((it) => to.endsWith(it))) return false;

  return chess
    .history({ verbose: true })
    .map((it) => it.to)
    .includes(to);
}

export const ChessBoard = memo(
  ({
    gameId,
    started,
    myColor,
    chess,
    board,
    socket,
    setBoard,
    // 🔹 NEW optional props for hint highlighting
    mostPlayedMove,
    bestEngineMove,
  }: {
    myColor: Color;
    gameId: string;
    started: boolean;
    chess: Chess;
    setBoard: React.Dispatch<
      React.SetStateAction<
        ({
          square: Square;
          type: PieceSymbol;
          color: Color;
        } | null)[][]
      >
    >;
    board: ({
      square: Square;
      type: PieceSymbol;
      color: Color;
    } | null)[][];
    socket: WebSocket;
    mostPlayedMove?: { from: Square; to: Square } | null;
    bestEngineMove?: { from: Square; to: Square } | null;
  }) => {
    console.log("chessboard reloaded");

    const [isFlipped, setIsFlipped] = useRecoilState(isBoardFlippedAtom);
    const [userSelectedMoveIndex, setUserSelectedMoveIndex] =
      useRecoilState(userSelectedMoveIndexAtom);
    const [moves, setMoves] = useRecoilState(movesAtom);
    const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(
      null
    );
    const [rightClickedSquares, setRightClickedSquares] = useState<string[]>([]);
    const [arrowStart, setArrowStart] = useState<string | null>(null);

    const [from, setFrom] = useState<null | Square>(null);
    const isTrainer = gameId === "trainer";
    const isMyTurn = isTrainer ? true : myColor === chess.turn();
    const [legalMoves, setLegalMoves] = useState<string[]>([]);

    const labels = ["a", "b", "c", "d", "e", "f", "g", "h"];
    const [canvas, setCanvas] = useState<HTMLCanvasElement | null>(null);
    const boxSize = 80;
    const [gameOver, setGameOver] = useState(false);
    const moveAudio = new Audio(moveSoundFile);
    const captureAudio = new Audio(captureSoundFile);

    const [lambdaInfo, setLambdaInfo] = useState<{
      lambda1: number;
      label: string;
    } | null>(null);
    const [isComputingLambda, setIsComputingLambda] = useState(false);

    async function updateLambda(fen: string) {
      try {
        setIsComputingLambda(true);
        const res = await fetchLambda(fen);
        setLambdaInfo(res);
      } catch (e) {
        console.error("λ₁ fetch error:", e);
        setLambdaInfo(null);
      } finally {
        setIsComputingLambda(false);
      }
    }

    const handleMouseDown = (
      e: MouseEvent<HTMLDivElement>,
      squareRep: string
    ) => {
      e.preventDefault();
      if (e.button === 2) {
        setArrowStart(squareRep);
      }
    };

    useEffect(() => {
      if (myColor === "b") {
        setIsFlipped(true);
      }
    }, [myColor, setIsFlipped]);

    const clearCanvas = () => {
      setRightClickedSquares([]);
      if (canvas) {
        const ctx = canvas.getContext("2d");
        ctx?.clearRect(0, 0, canvas.width, canvas.height);
      }
    };

    const handleRightClick = (squareRep: string) => {
      if (rightClickedSquares.includes(squareRep)) {
        setRightClickedSquares((prev) => prev.filter((sq) => sq !== squareRep));
      } else {
        setRightClickedSquares((prev) => [...prev, squareRep]);
      }
    };

    const handleDrawArrow = (squareRep: string) => {
      if (arrowStart) {
        const stoppedAtSquare = squareRep;
        if (canvas) {
          const ctx = canvas.getContext("2d");
          if (ctx) {
            drawArrow({
              ctx,
              start: arrowStart,
              end: stoppedAtSquare,
              isFlipped,
              squareSize: boxSize,
            });
          }
        }
        setArrowStart(null);
      }
    };

    const handleMouseUp = (
      e: MouseEvent<HTMLDivElement>,
      squareRep: string
    ) => {
      e.preventDefault();
      if (!started) return;

      if (e.button === 2) {
        if (arrowStart === squareRep) {
          handleRightClick(squareRep);
        } else {
          handleDrawArrow(squareRep);
        }
      } else {
        clearCanvas();
      }
    };

    useEffect(() => {
      clearCanvas();
      const lMove = moves.at(-1);
      if (lMove) {
        setLastMove({
          from: lMove.from,
          to: lMove.to,
        });
      } else {
        setLastMove(null);
      }
    }, [moves]);

    useEffect(() => {
      if (userSelectedMoveIndex !== null) {
        const move = moves[userSelectedMoveIndex];
        setLastMove({
          from: move.from,
          to: move.to,
        });
        chess.load(move.after);
        setBoard(chess.board());
        return;
      }
    }, [userSelectedMoveIndex, moves, chess, setBoard]);

    useEffect(() => {
      if (userSelectedMoveIndex !== null) {
        chess.reset();
        moves.forEach((move) => {
          chess.move({ from: move.from, to: move.to });
        });
        setBoard(chess.board());
        setUserSelectedMoveIndex(null);
      } else {
        setBoard(chess.board());
      }
    }, [moves, userSelectedMoveIndex, chess, setBoard, setUserSelectedMoveIndex]);

    // Recompute λ₁ whenever the board position changes
    useEffect(() => {
      const fen = chess.fen();
      updateLambda(fen);
    }, [board, chess]);

    return (
      <>
        {gameOver && <Confetti />}
        <div className="flex gap-6 items-start">
          {/* Board + arrows */}
          <div className="relative">
            <div className="text-white-200 rounded-md overflow-hidden">
              {(isFlipped ? board.slice().reverse() : board).map((row, i) => {
                i = isFlipped ? i + 1 : 8 - i;
                return (
                  <div key={i} className="flex relative">
                    <NumberNotation
                      isMainBoxColor={isFlipped ? i % 2 !== 0 : i % 2 === 0}
                      label={i.toString()}
                    />
                    {(isFlipped ? row.slice().reverse() : row).map((square, j) => {
                      j = isFlipped ? 7 - (j % 8) : j % 8;

                      const isMainBoxColor = (i + j) % 2 !== 0;
                      const isPiece: boolean = !!square;
                      const squareRepresentation = (
                        String.fromCharCode(97 + j) + "" + i
                      ) as Square;

                      const isHighlightedSquare =
                        from === squareRepresentation ||
                        squareRepresentation === lastMove?.from ||
                        squareRepresentation === lastMove?.to;
                      const isRightClickedSquare =
                        rightClickedSquares.includes(squareRepresentation);

                      const piece = square && square.type;
                      const isKingInCheckSquare =
                        piece === "k" &&
                        square?.color === chess.turn() &&
                        chess.inCheck();

                      // 🔹 NEW: hint highlighting flags
                      const isMostPlayedSquare =
                        mostPlayedMove &&
                        (squareRepresentation === mostPlayedMove.from ||
                          squareRepresentation === mostPlayedMove.to);

                      const isBestEngineSquare =
                        bestEngineMove &&
                        (squareRepresentation === bestEngineMove.from ||
                          squareRepresentation === bestEngineMove.to);

                      // Thick borders for hints
                      let outlineClass = "";
                      if (isMostPlayedSquare && isBestEngineSquare) {
                        // both coincide: cyan border
                        outlineClass =
                          " box-border border-[4px] border-cyan-400";
                      } else if (isBestEngineSquare) {
                        // engine best: green border
                        outlineClass =
                          " box-border border-[4px] border-emerald-400";
                      } else if (isMostPlayedSquare) {
                        // most played: yellow border
                        outlineClass =
                          " box-border border-[4px] border-yellow-300";
                      }

                      return (
                        <div
                          onClick={() => {
                            if (!started) return;

                            if (userSelectedMoveIndex !== null) {
                              chess.reset();
                              moves.forEach((move) => {
                                chess.move({ from: move.from, to: move.to });
                              });
                              setBoard(chess.board());
                              setUserSelectedMoveIndex(null);
                              return;
                            }

                            if (!from && square?.color !== chess.turn()) return;
                            if (!isMyTurn) return;

                            if (from != squareRepresentation) {
                              setFrom(squareRepresentation);
                              if (isPiece) {
                                setLegalMoves(
                                  chess
                                    .moves({
                                      verbose: true,
                                      square: square?.square,
                                    })
                                    .map((move) => move.to)
                                );
                              }
                            } else {
                              setFrom(null);
                            }

                            if (!isPiece) {
                              setLegalMoves([]);
                            }

                            if (!from) {
                              setFrom(squareRepresentation);
                              setLegalMoves(
                                chess
                                  .moves({
                                    verbose: true,
                                    square: square?.square,
                                  })
                                  .map((move) => move.to)
                              );
                            } else {
                              try {
                                let moveResult: Move;
                                if (
                                  isPromoting(chess, from, squareRepresentation)
                                ) {
                                  moveResult = chess.move({
                                    from,
                                    to: squareRepresentation,
                                    promotion: "q",
                                  });
                                } else {
                                  moveResult = chess.move({
                                    from,
                                    to: squareRepresentation,
                                  });
                                }
                                if (moveResult) {
                                  moveAudio.play();

                                  if (moveResult?.captured) {
                                    captureAudio.play();
                                  }
                                  setMoves((prev) => [...prev, moveResult]);
                                  setFrom(null);
                                  setLegalMoves([]);
                                  if (moveResult.san.includes("#")) {
                                    setGameOver(true);
                                  }
                                  socket.send(
                                    JSON.stringify({
                                      type: MOVE,
                                      payload: {
                                        gameId,
                                        move: moveResult,
                                      },
                                    })
                                  );
                                }
                              } catch (e) {
                                console.log("e", e);
                              }
                            }
                          }}
                          style={{
                            width: boxSize,
                            height: boxSize,
                          }}
                          key={j}
                          className={`${
                            isRightClickedSquare
                              ? isMainBoxColor
                                ? "bg-[#CF664E]"
                                : "bg-[#E87764]"
                              : isKingInCheckSquare
                              ? "bg-[#FF6347]"
                              : isHighlightedSquare
                              ? `${
                                  isMainBoxColor
                                    ? "bg-[#BBCB45]"
                                    : "bg-[#F4F687]"
                                }`
                              : isMainBoxColor
                              ? "bg-boardDark"
                              : "bg-boardLight"
                          }${outlineClass}`}
                          onContextMenu={(e) => {
                            e.preventDefault();
                          }}
                          onMouseDown={(e) => {
                            handleMouseDown(e, squareRepresentation);
                          }}
                          onMouseUp={(e) => {
                            handleMouseUp(e, squareRepresentation);
                          }}
                        >
                          <div className="w-full justify-center flex h-full relative">
                            {square && <ChessSquare square={square} />}
                            {isFlipped
                              ? i === 8 && (
                                  <LetterNotation
                                    label={labels[j]}
                                    isMainBoxColor={j % 2 === 0}
                                  />
                                )
                              : i === 1 && (
                                  <LetterNotation
                                    label={labels[j]}
                                    isMainBoxColor={j % 2 !== 0}
                                  />
                                )}
                            {!!from &&
                              legalMoves.includes(squareRepresentation) && (
                                <LegalMoveIndicator
                                  isMainBoxColor={isMainBoxColor}
                                  isPiece={!!square?.type}
                                />
                              )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>

            <canvas
              ref={(ref) => setCanvas(ref)}
              width={boxSize * 8}
              height={boxSize * 8}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                pointerEvents: "none",
              }}
              onContextMenu={(e) => e.preventDefault()}
              onMouseDown={(e) => {
                e.preventDefault();
              }}
              onMouseUp={(e) => e.preventDefault()}
            ></canvas>
          </div>

{/* λ₁ tension panel */}
<div className="text-white text-sm space-y-2">
  <div className="font-semibold">Tension (λ₁)</div>

  {lambdaInfo ? (
    <div className="bg-black/70 px-4 py-2 rounded-md shadow">
      <div>λ₁: {lambdaInfo.lambda1.toFixed(2)}</div>
      <div>Level: {lambdaInfo.label}</div>
    </div>
  ) : (
    <div className="text-gray-300">Make a move to see the current tension.</div>
  )}

  {isComputingLambda && (
    <div className="text-xs text-green-300 animate-pulse">
      Computing λ…
    </div>
  )}

  {/* Hint Legend */}
  <div className="bg-black/70 px-4 py-2 rounded-md shadow mt-2 text-xs space-y-1">
    <div className="font-semibold mb-1">Hint Legend</div>

    <div className="flex items-center gap-2">
      <div className="w-3 h-3 rounded-sm bg-emerald-400"></div>
      <span className="text-emerald-300">Best Move (Engine)</span>
    </div>

    <div className="flex items-center gap-2">
      <div className="w-3 h-3 rounded-sm bg-yellow-300"></div>
      <span className="text-yellow-200">Most Played Move</span>
    </div>

    <div className="flex items-center gap-2">
      <div className="w-3 h-3 rounded-sm bg-cyan-400"></div>
      <span className="text-cyan-300">Both</span>
    </div>
  </div>
</div>  {/* ← THIS is the missing div you needed */}
</div>      {/* ← This closes the right-side panel wrapper */}
</>
);
}
);