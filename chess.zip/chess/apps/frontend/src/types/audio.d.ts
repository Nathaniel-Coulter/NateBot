declare module '*.wav' {
  const src: string;
  export default src;
}