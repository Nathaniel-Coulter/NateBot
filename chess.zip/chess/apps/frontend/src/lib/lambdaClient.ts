// apps/frontend/src/lib/lambdaClient.ts

const API_BASE = "http://127.0.0.1:5000";

/* ---------- λ₁ (tension) ---------- */

export type LambdaResponse = {
  lambda1: number;
  label: string;
};

export async function fetchLambda(fen: string): Promise<LambdaResponse> {
  const res = await fetch(`${API_BASE}/lambda`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ fen }),
  });

  if (!res.ok) {
    throw new Error(`Lambda API error: ${res.status}`);
  }

  const data = await res.json();
  return {
    lambda1: data.lambda1,
    label: data.label,
  };
}

/* ---------- Opening stats (Lichess explorer) ---------- */

export type OpeningMove = {
  uci: string;
  san: string;
  games: number;
  p_white: number;
  p_draw: number;
  p_black: number;
};

export type OpeningStats = {
  total_games: number;
  moves: OpeningMove[];
};

export async function fetchOpeningStats(fen: string): Promise<OpeningStats> {
  const res = await fetch(`${API_BASE}/opening-stats`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ fen }),
  });

  if (!res.ok) {
    throw new Error("Failed to fetch opening stats");
  }

  return (await res.json()) as OpeningStats;
}

/* ---------- Best moves (Stockfish) ---------- */

// Raw format returned by /best-move
export type EngineMove = {
  uci: string;
  san: string;
  score: string;          // e.g. "+0.45" or "#3"
  score_cp: number | null; // centipawns if non-mate, else null
};

// Normalized format Trainer will use
export type EngineLine = {
  move: string;   // UCI, e.g. "e2e4"
  pretty: string; // SAN, e.g. "e4"
  score: number;  // evaluation in pawns (or ±999 for mate)
};

export async function fetchBestMoves(fen: string): Promise<EngineMove[]> {
  const res = await fetch(`${API_BASE}/best-move`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ fen }),
  });

  if (!res.ok) {
    throw new Error("Failed to fetch best moves");
  }

  const data = await res.json();
  return (data.moves ?? []) as EngineMove[];
}

/**
 * Wrapper that normalizes the raw engine output into EngineLine[]
 * for easier use in Trainer.tsx
 */
export async function fetchEngineBestLines(
  fen: string
): Promise<EngineLine[]> {
  const raw = await fetchBestMoves(fen);

  return raw.map((m) => {
    let numericEval = 0;

    if (m.score.startsWith("#")) {
      // Mate evaluation → big sentinel value
      const mateDistance = parseInt(m.score.replace("#", ""), 10);
      numericEval = mateDistance > 0 ? 999 : -999;
    } else if (m.score_cp != null) {
      numericEval = m.score_cp / 100; // centipawns → pawns
    }

    return {
      move: m.uci,
      pretty: m.san,
      score: numericEval,
    };
  });
}