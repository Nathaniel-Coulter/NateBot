from flask import Flask, request, jsonify
from flask_cors import CORS
import chess
import chess.engine
import numpy as np
import requests

# ----------------------------------------
# CONSTANTS
# ----------------------------------------
LICHESS_EXPLORER_URL = "https://explorer.lichess.ovh/lichess"

# 🔹 YOUR STOCKFISH PATH (CORRECT)
STOCKFISH_PATH = r"C:\Users\hocke\Desktop\chess_trainer\backend\stockfish\stockfish-windows-x86-64-avx2.exe"


app = Flask(__name__)
CORS(app)


# ----------------------------------------
# START STOCKFISH ENGINE
# ----------------------------------------
try:
    engine = chess.engine.SimpleEngine.popen_uci(STOCKFISH_PATH)
    print("Stockfish engine loaded successfully.")
except Exception as e:
    print("ERROR: Could not start Stockfish engine:", e)
    engine = None


# ----------------------------------------
# λ₁: GRAPH-BASED POSITION TENSION
# ----------------------------------------
def compute_lambda1_from_fen(fen: str) -> float:
    board = chess.Board(fen)
    piece_squares = list(board.piece_map().keys())
    n = len(piece_squares)

    if n <= 1:
        return 0.0

    A = np.zeros((n, n), dtype=float)
    attacks_by_index = [board.attacks(sq) for sq in piece_squares]

    for i in range(n):
        for j in range(i + 1, n):
            if (piece_squares[j] in attacks_by_index[i]) or (
                piece_squares[i] in attacks_by_index[j]
            ):
                A[i, j] = 1.0
                A[j, i] = 1.0

    try:
        eigvals = np.linalg.eigvals(A)
        return float(np.max(eigvals.real))
    except Exception:
        return 0.0


# ----------------------------------------
# HEALTH CHECK
# ----------------------------------------
@app.route("/")
def healthcheck():
    return "Chess λ₁ API OK"


# ----------------------------------------
# λ₁ ENDPOINT
# ----------------------------------------
@app.route("/lambda", methods=["POST"])
def lambda_endpoint():
    data = request.get_json()
    if not data or "fen" not in data:
        return jsonify({"error": "Missing 'fen'"}), 400

    fen = data["fen"]
    lambda1 = compute_lambda1_from_fen(fen)

    # simple tension label
    if lambda1 < 2.0:
        label = "Low tension"
    elif lambda1 < 4.0:
        label = "Moderate tension"
    else:
        label = "High tension"

    return jsonify({"lambda1": round(lambda1, 4), "label": label})


# ----------------------------------------
# OPENING STATS (LICHESS EXPLORER)
# ----------------------------------------
@app.route("/opening-stats", methods=["POST"])
def opening_stats():
    data = request.get_json()
    fen = data.get("fen")
    if not fen:
        return jsonify({"error": "Missing 'fen'"}), 400

    params = {
        "fen": fen,
        "moves": 20,
        "topGames": 0,
        "recentGames": 0,
    }

    try:
        resp = requests.get(LICHESS_EXPLORER_URL, params=params, timeout=3)
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as e:
        print("Explorer API error:", e)
        return jsonify({"error": "Lichess explorer failed"}), 502

    moves = payload.get("moves", [])
    top_moves = []
    total_games = 0

    for m in moves:
        white = m.get("white", 0)
        draws = m.get("draws", 0)
        black = m.get("black", 0)
        total = white + draws + black
        total_games += total

        total = total if total > 0 else 1
        top_moves.append({
            "san": m.get("san"),
            "uci": m.get("uci"),
            "games": total,
            "p_white": white / total,
            "p_draw": draws / total,
            "p_black": black / total,
        })

    return jsonify({"total_games": total_games, "moves": top_moves})


# ----------------------------------------
# STOCKFISH ENGINE BEST-MOVE ENDPOINT
# ----------------------------------------
@app.route("/best-move", methods=["POST"])
def best_move():
    if engine is None:
        return jsonify({"error": "Stockfish engine unavailable"}), 500

    data = request.get_json()
    fen = data.get("fen")
    if not fen:
        return jsonify({"error": "Missing 'fen'"}), 400

    board = chess.Board(fen)

    try:
        limit = chess.engine.Limit(time=0.3)
        info_list = engine.analyse(board, limit=limit, multipv=3)
    except Exception as e:
        print("Stockfish error:", e)
        return jsonify({"error": "Engine failure"}), 500

    result = []
    for info in info_list:
        pv = info.get("pv")
        if not pv:
            continue
        move = pv[0]

        score = info["score"].pov(board.turn)
        if score.is_mate():
            score_str = f"#{score.mate()}"
            score_cp = None
        else:
            cp = score.score(mate_score=100000)
            score_str = f"{cp / 100:.2f}"
            score_cp = cp

        result.append({
            "uci": move.uci(),
            "san": board.san(move),
            "score": score_str,
            "score_cp": score_cp,
        })

    return jsonify({"moves": result})


# ----------------------------------------
# RUN SERVER
# ----------------------------------------
if __name__ == "__main__":
    try:
        app.run(port=5000, debug=True)
    finally:
        if engine:
            engine.quit()